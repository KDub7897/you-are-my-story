═══════════════════════════════════════════════════════════════════════════
  PHOTO UPLOAD GUIDE — You Are My Story
═══════════════════════════════════════════════════════════════════════════

Drop photos in THIS folder (/public/images/) using the EXACT filenames below.
Lowercase. Hyphens (not underscores). .jpg extension. No spaces.

If a photo is missing, the app shows an emoji fallback — it won't crash.
You can deploy first and add photos later via the Vercel dashboard.

───────────────────────────────────────────────────────────────────────────
  DR. VAGGERS COLLECTION (the duck)
───────────────────────────────────────────────────────────────────────────
  vaggers-classic.jpg     →  Dr. Vaggers in his clinical pose (default)
  vaggers-googly.jpg      →  Vaggers with the googly eyes / Nurse Beak
  vaggers-pucker.jpg      →  Vaggers puckered up
  vaggers-bondage.jpg     →  Vaggers tied up / kinky shot
  vaggers-kit.jpg         →  Vaggers in his medical kit
  vaggers-thong.jpg       →  Vaggers in the thong
  vaggers-road.jpg        →  Vaggers road-trip ready

───────────────────────────────────────────────────────────────────────────
  CLUCK NORRIS (the chicken)
───────────────────────────────────────────────────────────────────────────
  cluck-classic.jpg       →  Cluck Norris solo
  cluck-vaggers.jpg       →  Cluck and Vaggers together

───────────────────────────────────────────────────────────────────────────
  KELLI BITMOJIS (Demon)
───────────────────────────────────────────────────────────────────────────
  bm-wanna.jpg            →  WANNA face Bitmoji
  bm-poot.jpg             →  the poot Bitmoji
  bm-jail.jpg             →  jail Bitmoji
  bm-squirrel.jpg         →  squirrel Bitmoji
  bm-platypus.jpg         →  platypus Bitmoji
  bm-fuse.jpg             →  short-fuse Bitmoji

───────────────────────────────────────────────────────────────────────────
  COUPLE BITMOJIS (Demon + Python)
───────────────────────────────────────────────────────────────────────────
  bm-couple-sit.jpg       →  the two of us sitting
  bm-couple-run.jpg       →  running away together
  bm-couple-pose.jpg      →  posing
  bm-couple-scared.jpg    →  scared/clinging
  bm-couple-heart.jpg     →  heart-eyes / love

───────────────────────────────────────────────────────────────────────────
  REAL PHOTOS — for "Remember This" memory game
───────────────────────────────────────────────────────────────────────────
  real-taboo.jpg          →  the Taboo show photo
  real-harley.jpg         →  the Harley ride
  real-date1.jpg          →  anniversary dinner / steak
  real-date2.jpg          →  the date we walked home from
  real-date3.jpg          →  the trip-day where you laughed so hard
  real-selfie1.jpg        →  the recovery face selfie
  real-selfie2.jpg        →  any couple selfie #2
  real-selfie3.jpg        →  any couple selfie #3

  (If you swap any of these, just match the filename. The questions live in
   page.js inside the REMEMBER array — line ~478 — and you can edit the
   `q` and `a` text to match whatever photo you put there.)

───────────────────────────────────────────────────────────────────────────
  PETS / MISC
───────────────────────────────────────────────────────────────────────────
  stella.jpg              →  Stella the white dog with drawn-on eyebrows
  couch-dog.jpg           →  dog on the couch
  raccoon.jpg             →  the raccoon shot
  the-gang.jpg            →  group photo of the whole crew

───────────────────────────────────────────────────────────────────────────
  ART
───────────────────────────────────────────────────────────────────────────
  art-superhero.jpg       →  superhero art piece
  art-kissing.jpg         →  the kissing art
  art-snake-penguin.jpg   →  snake + penguin art (Python + Penguin)

───────────────────────────────────────────────────────────────────────────
  HERO
───────────────────────────────────────────────────────────────────────────
  hero-chase.jpg          →  cover image for "The Chase" theme

═══════════════════════════════════════════════════════════════════════════
  TOTAL: 38 photo slots. All optional — missing ones fall back to emojis.
═══════════════════════════════════════════════════════════════════════════
